declare namespace Cloudflare {
  interface Env {
    ASSETS: Fetcher;
    SUPABASE_URL: string;
    SUPABASE_SERVICE_ROLE_KEY: string;
  }
}
